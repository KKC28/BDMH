#!/usr/bin/env python
# coding: utf-8

# In[ ]:


#Komal Kumari(MT19124)
#Sonali(MT19081)
#Bhakti(MT19115)
#Prerna verma(MT19079)


# In[99]:


import numpy as np
import pandas as pd
import shutil
import skimage.io
from sklearn.ensemble import BaggingClassifier
import os
import imutils
from sklearn.metrics import confusion_matrix
import skimage.transform
from sklearn.neural_network import MLPClassifier
from os import listdir
from sklearn.ensemble import GradientBoostingClassifier
import sys
from sklearn.preprocessing import LabelEncoder
from sklearn.preprocessing import MinMaxScaler
import numpy as np
import mahotas
import cv2
import os
import h5py
import matplotlib.pyplot as plt 
from skimage.feature import hog
import warnings
from matplotlib import pyplot
from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.model_selection import KFold, StratifiedKFold
from sklearn.metrics import confusion_matrix, accuracy_score, classification_report,recall_score,precision_score,f1_score
from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.neighbors import KNeighborsClassifier
from sklearn.discriminant_analysis import LinearDiscriminantAnalysis
from sklearn.naive_bayes import GaussianNB
from sklearn.svm import SVC
from sklearn.externals import joblib


# Data balancing by vertical flipping of images

# In[39]:


def imageAugmntation(image,count,target_dir):
    img=cv2.imread(image) 
    img=cv2.cvtColor(img,cv2.COLOR_BGR2RGB)
    vertical_img = img.copy()
    vertical_img = cv2.flip( img, 1 )
    cv2.imwrite(target_dir+'/'+'Train_'+str(count)+'.jpg',cv2.cvtColor(vertical_img, cv2.COLOR_BGR2RGB))


# Setting parameters

# In[81]:


size=tuple((500, 500))
train_path="./brain_tumor_dataset/"
h5_data='./output/Take_6/data.h5'
h5_labels='./output/Take_6/labels.h5'
bins=8
seed=9
scoring="accuracy"
test_size=0.10
num_trees=700


# In[43]:


train_labels = os.listdir(train_path)
train_labels = list(map(int, train_labels))
train_labels.sort()
print("Training Labels:",train_labels)
globalFeat = []
labels=[]


# In[ ]:


#changing names
# count=1
# for training_name in train_labels: #data balancing
#     # join the training data path and each species training folder
#     dir = os.path.join(train_path, str(training_name))
#     for file in listdir(dir):
#         if not file.startswith('.'):
#             os.rename(dir+'/'+file,dir+'/Train_'+str(count)+'.jpg')
#         print(count)
#         count+=1


# Checking Shapes of the dataset

# In[45]:


#checking shapes
for training_name in train_labels: #data balancing
    dir = os.path.join(train_path, str(training_name))
    for f in os.listdir(dir):
        if not f.startswith('.'):
            img = cv2.imread(dir+'/'+f)
            print("shape:",img.shape)


# Cropping fo images by Gray Scale conversion, median flitering, erosion, dilationa and finding contours.

# In[ ]:


def crop_imgs(img, add_pixels_value=0):
        #gray scale conversion of images
        gray = cv2.cvtColor(img, cv2.COLOR_RGB2GRAY)
        
        #median filtering of image
        median = cv2.medianBlur(gray, 5)
        
        #image thresholding
        thresh = cv2.threshold(median, 45, 255, cv2.THRESH_BINARY)[1]
        
        #image erosion
        thresh_erode = cv2.erode(thresh, None, iterations=2)
        
        #image dilation
        thresh_dilate = cv2.dilate(thresh_erode, None, iterations=2)
        
        #contouring of image
        cnts = cv2.findContours(thresh_dilate.copy(), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        cnts = imutils.grab_contours(cnts)
        c = max(cnts, key=cv2.contourArea)
        extLeft = tuple(c[c[:, :, 0].argmin()][0])
        extRight = tuple(c[c[:, :, 0].argmax()][0])
        extTop = tuple(c[c[:, :, 1].argmin()][0])
        extBot = tuple(c[c[:, :, 1].argmax()][0])
        ADD_PIXELS = add_pixels_value
        
        #forming new image
        new_img = img[extTop[1]-ADD_PIXELS:extBot[1]+ADD_PIXELS, extLeft[0]-ADD_PIXELS:extRight[0]+ADD_PIXELS].copy()
        #print("hhe;p")
        return new_img
        
        
for training_name in train_labels: 
    dir = os.path.join(train_path, str(training_name))
    for f in os.listdir(dir):
        if not f.startswith('.'):
            img = cv2.imread(dir+'/'+f)
            new_img=crop_imgs(img, add_pixels_value=0)
            cv2.imwrite(dir+'/'+f, new_img)


# Main code for data augmentation for data balancing

# In[49]:


for training_name in train_labels: #data balancing
    dir = os.path.join(train_path, str(training_name))
    count=0
    for f in os.listdir(dir):
        if not f.startswith('.'):
            count+=1 
    file_name=254
    for file in listdir(dir):
        if not file.startswith('.'):
            if(count<155):
                imageAugmntation(dir+'/'+file,file_name,dir)
                file_name+=1
                count+=1


# Feature Selection/Extraction Methods

# In[112]:


#HOG feature extaction
def hogD(image,hog_pixels_per_cell=64,hog_cells_per_block=1):# hog features
    gray = cv2.cvtColor(image, cv2.COLOR_RGB2GRAY)
    hog_desriptor=hog(gray,orientations=8,pixels_per_cell=(hog_pixels_per_cell,hog_pixels_per_cell),cells_per_block=(hog_cells_per_block, hog_cells_per_block),feature_vector=True)
    return hog_desriptor


# In[50]:


#HU-Moments feature selection
def hu_momentsF(image):# hu_moments features
    image=cv2.cvtColor(image,cv2.COLOR_RGB2GRAY)
    feature=cv2.HuMoments(cv2.moments(image)).flatten()
    return feature


# In[51]:


#Haralick feature selection
def haralickF(image): #haralick feature
    gray=cv2.cvtColor(image,cv2.COLOR_RGB2GRAY)
    haralick=mahotas.features.haralick(gray).mean(axis=0)
    return haralick


# In[52]:


#Colour Histogram Feature selection
def histogramF(image, mask=None): #histogram featurs
    image=cv2.cvtColor(image,cv2.COLOR_BGR2HSV)
    hist=cv2.calcHist([image],[0, 1, 2],None,[bins, bins, bins],[0, 256, 0, 256, 0, 256])
    cv2.normalize(hist,hist)
    return hist.flatten()


# Main code for feature selection/extraction and merging of features from different methods

# In[53]:


training_data_feature_map={} #combining all features generated
daisy_descriptor_list=[]
for training_name in train_labels:
    dir=os.path.join(train_path, str(training_name))
    label=training_name
    for file in listdir(dir):
        image=cv2.imread(dir+'/'+file)
        image=cv2.resize(image,size)
        haralick=haralickF(image)
        hu_moments=hu_momentsF(image)
        histogram=histogramF(image)
        globalF=np.hstack([histogram, haralick, hu_moments])
        labels.append(label)
        globalFeat.append(globalF)
print("Done")


# Saving features extracted`

# In[55]:


print("Shape of features extracted:",np.array(globalFeat).shape)
target=labels
scaler=MinMaxScaler(feature_range=(0, 1))
scaled=scaler.fit_transform(globalFeat)
h5f_data = h5py.File(h5_data, 'w')
h5f_data.create_dataset('dataset_1',data=np.array(scaled))
h5f_label = h5py.File(h5_labels, 'w')
h5f_label.create_dataset('dataset_1',data=np.array(target))
h5f_data.close()
h5f_label.close()


# Defining models onto which training dataset will be fed

# In[62]:


models = []
models.append(('LR', LogisticRegression(random_state=seed)))
models.append(('LDA', LinearDiscriminantAnalysis()))
models.append(('KNN', KNeighborsClassifier()))
models.append(('CART', DecisionTreeClassifier(random_state=seed)))
models.append(('RF', RandomForestClassifier(n_estimators=num_trees, max_depth=50,random_state=0,min_samples_split=2)))
models.append(('GB',GradientBoostingClassifier(n_estimators=20, learning_rate=0.5, max_features=2, max_depth=2, random_state=0)))
models.append(('NB', GaussianNB()))
svm=SVC(kernel='rbf', class_weight='balanced',C=5,gamma=0.005,random_state=seed)
models.append(('Bagged SVM', BaggingClassifier(base_estimator=svm, n_estimators=100, random_state=42) ))
models.append(('SVM', SVC(kernel='rbf', class_weight='balanced',C=5,gamma=0.005,random_state=seed)))

results = []
names   = []

# import the feature vector and trained labels
h5f_data  = h5py.File(h5_data, 'r')
h5f_label = h5py.File(h5_labels, 'r')

global_features_string = h5f_data['dataset_1']
global_labels_string   = h5f_label['dataset_1']

global_features = np.array(global_features_string)
global_labels   = np.array(global_labels_string)

h5f_data.close()
h5f_label.close()


# Train-Test Split of dataset

# In[63]:


(train, test, trainLabels, testLabels) = train_test_split(np.array(global_features),np.array(global_labels),test_size=test_size,random_state=seed)                                           
print("Train data  :",train.shape)
print("Test data   :",test.shape)
print("Train labels:",train.shape)
print("Test labels :",test.shape)


# Cross Validation on 5-Folds fro training the models and comparing the perfromances

# Training Dataset Evaluation

# 1. Accuarcy Score permonce comparison

# In[83]:


results = []
names   = []

for name, model in models:
    kfold = KFold(n_splits=10, random_state=seed)
    cv_results = cross_val_score(model, train, trainLabels, cv=kfold, scoring=scoring)
    results.append(cv_results)
    names.append(name)
    msg = "%s: %f (%f)" % (name, cv_results.mean(), cv_results.std())
    print(msg)
fig = pyplot.figure(figsize=(18,5))
fig.suptitle('Machine Learning algorithm comparison on basis of Accuracy')
ax = fig.add_subplot(111)
pyplot.boxplot(results)
ax.set_xticklabels(names)
ax.set_xlabel('Models')
ax.set_ylabel('Accuarcy Score')
pyplot.show()


# 2. Sensitivity/Recall basis performance comaprison

# In[84]:


results=[]
names=[]
scoring='recall'
for name, model in models:
    kfold = KFold(n_splits=10, random_state=seed)
    cv_results = cross_val_score(model, train, trainLabels, cv=kfold, scoring=scoring)
    results.append(cv_results)
    names.append(name)
    msg = "%s: %f (%f)" % (name, cv_results.mean(), cv_results.std())
    print(msg)

# boxplot algorithm comparison
fig = pyplot.figure(figsize=(18,5))
fig.suptitle('Machine Learning algorithm comparison on basis of Recall/Sensitivity')
ax = fig.add_subplot(111)
pyplot.boxplot(results)
ax.set_xticklabels(names)
ax.set_xlabel('Models')
ax.set_ylabel('Sensitivity/Recall Score')
pyplot.show()


# 3. Precision basis performance comaprison

# In[85]:


scoring='precision'
results=[]
names=[]
for name, model in models:
    kfold = KFold(n_splits=10, random_state=seed)
    cv_results = cross_val_score(model, train, trainLabels, cv=kfold, scoring=scoring)
    results.append(cv_results)
    names.append(name)
    msg = "%s: %f (%f)" % (name, cv_results.mean(), cv_results.std())
    print(msg)

# boxplot algorithm comparison
fig = pyplot.figure(figsize=(18,5))
fig.suptitle('Machine Learning algorithm comparison on basis of Precision ')
ax = fig.add_subplot(111)
pyplot.boxplot(results)
ax.set_xticklabels(names)
ax.set_xlabel('Models')
ax.set_ylabel('Precision Score')
pyplot.show()


# 4. F1-score basis performance comaprison

# In[86]:


scoring='f1'
results=[]
names=[]
for name, model in models:
    kfold = KFold(n_splits=10, random_state=seed)
    cv_results = cross_val_score(model, train, trainLabels, cv=kfold, scoring=scoring)
    results.append(cv_results)
    names.append(name)
    msg = "%s: %f (%f)" % (name, cv_results.mean(), cv_results.std())
    print(msg)

# boxplot algorithm comparison
fig = pyplot.figure(figsize=(18,5))
fig.suptitle('Machine Learning algorithm comparison on basis of F1-score')
ax = fig.add_subplot(111)
pyplot.boxplot(results)
ax.set_xticklabels(names)
ax.set_xlabel('Models')
ax.set_ylabel('F1 Score')
pyplot.show()


# Testing Dataset Evalaution

#  1. Accuarcy Score permonce comparison

# In[108]:


results=[]
names=[]
for name, model in models:
    #print(model)
    model.fit(train,trainLabels)
    y_pred=model.predict(test)
    temp=accuracy_score(testLabels,y_pred)
    results.append(temp)
    names.append(name)
    msg = "%s: %f" % (name,temp)
    print(msg)

y_pos = np.arange(len(names))
plt.barh(y_pos, results,)
plt.yticks(y_pos, names)
plt.title("Machine Learning algorithm comparison on basis of Accuracy")
plt.xlabel('Accuracy Score')
color=(0.2, 0.4, 0.6, 0.6)
plt.show()


# 2. Sensitivity/Recall basis performance comaprison

# In[109]:


results=[]
names=[]
for name, model in models:
    #print(model)
    model.fit(train,trainLabels)
    y_pred=model.predict(test)
    temp=recall_score(testLabels,y_pred)
    results.append(temp)
    names.append(name)
    msg = "%s: %f" % (name,temp)
    print(msg)

y_pos = np.arange(len(names))
plt.barh(y_pos, results)
plt.yticks(y_pos, names)
plt.title("Machine Learning algorithm comparison on basis of Sensitivity/Recall")
plt.xlabel('Sensitivity/Recall Score')
plt.show()


# 3. Precision basis performance comaprison

# In[110]:


results=[]
names=[]
for name, model in models:
    #print(model)
    model.fit(train,trainLabels)
    y_pred=model.predict(test)
    temp=precision_score(testLabels,y_pred)
    results.append(temp)
    names.append(name)
    msg = "%s: %f" % (name,temp)
    print(msg)

y_pos = np.arange(len(names))
plt.barh(y_pos, results)
plt.yticks(y_pos, names)
plt.title("Machine Learning algorithm comparison on basis of Precision")
plt.xlabel('Precision Score')
plt.show()


# In[ ]:


4. F1-score basis performance comaprison


# In[111]:


results=[]
names=[]
for name, model in models:
    #print(model)
    model.fit(train,trainLabels)
    y_pred=model.predict(test)
    temp=f1_score(testLabels,y_pred)
    results.append(temp)
    names.append(name)
    msg = "%s: %f" % (name,temp)
    print(msg)

y_pos = np.arange(len(names))
plt.barh(y_pos, results)
plt.yticks(y_pos, names)
plt.title("Machine Learning algorithm comparison on basis of F1 score")
plt.xlabel('F1 score')
plt.show()


# 5. Specificity basis performance comaprison

# In[100]:


results=[]
names=[]
for name, model in models:
    #print(model)
    model.fit(train,trainLabels)
    y_pred=model.predict(test)
    tn, fp, fn, tp = confusion_matrix(testLabels,y_pred).ravel()
    temp=tn / (tn + fp)
    results.append(temp)
    names.append(name)
    msg = "%s: %f" % (name,temp)
    print(msg)

y_pos = np.arange(len(names))
plt.barh(y_pos, results)
plt.yticks(y_pos, names)
plt.title("Machine Learning algorithm comparison on basis of Specificity")
plt.xlabel('Specificity score')
plt.show()

