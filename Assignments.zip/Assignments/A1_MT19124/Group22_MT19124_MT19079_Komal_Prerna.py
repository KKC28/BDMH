#Group22_MT19124_MT19079_Komal_Prerna
#!/usr/bin/env python
# coding: utf-8

# In[1]:


import csv,json


# In[2]:


csv_file="Group22_MT19124_MT19079_Komal_Prerna.csv"
json_file="Group22_MT19124_MT19079_Komal_Prerna.json"


# In[3]:


#craeting a dictionary
data={}

#reading csv file
with open(csv_file) as csvfile:
    csvreader=csv.DictReader(csvfile)
    for csvrow in csvreader:
        id_=csvrow["ID"]
        data[id_]=csvrow
print(data)


# In[4]:


#creating JSON file:
with open(json_file,"w") as jsonfile:
    jsonfile.write(json.dumps(data,indent=4))


# In[ ]:




